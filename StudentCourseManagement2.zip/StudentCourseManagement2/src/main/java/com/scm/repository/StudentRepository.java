package com.scm.repository;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface StudentRepository {

    Student save(Student newStudent);

    Student update(Student updatedStudent);

    void remove(Student student);

    Optional<Student> findById(Integer id);

    Optional<Student> findByEmail(String email);

    List<Student> findAll();

    List<StudentCourse> findStudentsCourseById(Integer studentId);

}
