package com.scm.repository;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface CourseRepository {

    Course save(Course newCourse);

    Course update(Course updatedCourse);

    void remove(Course course);

    Optional<Course> findById(Integer courseId);

    Optional<Course> findByName(String courseName);

    List<Course> findAll();

    List<StudentCourse> findStudentsByCourse(Integer courseId);

}
