package com.scm.repository;

import com.scm.entity.StudentCourse;

import java.util.Optional;

public interface AdminRepository {

    void registerCourse(StudentCourse studentCourse);

    Optional<StudentCourse> findById(Integer studentId, Integer courseId);

    void deleteStudentCourseRegistration(StudentCourse studentCourse);

    Long findCountOfRegistration(Integer courseId);

}
