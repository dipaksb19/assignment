package com.scm.repositoryimpl;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;
import com.scm.entitymanager.EntityManagerUtilityClass;
import com.scm.repository.CourseRepository;
import jakarta.persistence.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public class CourseRepositoryImpl implements CourseRepository {

    private final EntityManagerFactory entityManagerFactory = EntityManagerUtilityClass.getEntityManagerFactoryInstance();
    private EntityManager entityManager ;


    private  EntityManager getEntityManager(){
        if(entityManager == null || !entityManager.isOpen() ){
            entityManager = entityManagerFactory.createEntityManager();
        }
        return entityManager;
    }

    private void beginTransaction(){
        getEntityManager().getTransaction().begin();
    }

    private void commitTransaction(){
        getEntityManager().getTransaction().commit();
    }


    @Override
    public Course save(Course newCourse) {
        getEntityManager().persist(newCourse);
        commitTransaction();
        getEntityManager().close();
        return newCourse;
    }

    @Override
    public Course update(Course updatedCourse) {
        beginTransaction();
        Course dbCourse = getEntityManager().merge(updatedCourse);
        getEntityManager().lock(dbCourse, LockModeType.OPTIMISTIC);
        commitTransaction();
        getEntityManager().close();
        return dbCourse;
    }

    @Override
    public void remove(Course course) {
        beginTransaction();
        getEntityManager().remove(course);
        commitTransaction();
        getEntityManager().close();

    }

    @Override
    public Optional<Course> findById(Integer courseId) {
        beginTransaction();
        Optional<Course> course = Optional.ofNullable(getEntityManager().find(Course.class, courseId));
        commitTransaction();
        return course;
    }

    @Override
    public Optional<Course> findByName(String courseName) throws NoResultException, NonUniqueResultException {
        beginTransaction();
        TypedQuery<Course> courseByName = getEntityManager().createQuery("select e from Course e where e.courseName =: courseName", Course.class);
        courseByName.setParameter("courseName", courseName);
        Course existingStudent = courseByName.getSingleResult();
        commitTransaction();
        return Optional.ofNullable(existingStudent);
    }

    @Override
    public List<Course> findAll() {
        beginTransaction();
        TypedQuery<Course> courseList = getEntityManager().createQuery("select e from Course e", Course.class);
        commitTransaction();
        return courseList.getResultList();
    }

    @Override
    public List<StudentCourse> findStudentsByCourse(Integer courseId) {
        beginTransaction();
        Course course = getEntityManager().find(Course.class, courseId);
        List<StudentCourse> studentCourses = course.getStudentCourses();
        commitTransaction();
        return studentCourses;
    }
}
