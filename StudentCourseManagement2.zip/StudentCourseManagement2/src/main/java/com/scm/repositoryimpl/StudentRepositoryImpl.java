package com.scm.repositoryimpl;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;
import com.scm.entitymanager.EntityManagerUtilityClass;
import com.scm.repository.StudentRepository;
import jakarta.persistence.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public class StudentRepositoryImpl implements StudentRepository {

    private final EntityManagerFactory entityManagerFactory = EntityManagerUtilityClass.getEntityManagerFactoryInstance();
    private EntityManager entityManager;


    private  EntityManager getEntityManager(){
        if(entityManager == null || !entityManager.isOpen() ){
            entityManager = entityManagerFactory.createEntityManager();
        }
        return entityManager;
    }


    private void beginTransaction(){
        getEntityManager().getTransaction().begin();
    }

    private void commitTransaction(){
        getEntityManager().getTransaction().commit();
    }


    @Override
    public Student save(Student newStudent) {
        getEntityManager().persist(newStudent);
        commitTransaction();
        getEntityManager().close();
        return newStudent;
    }

    @Override
    public Student update(Student updatedStudent) {
        beginTransaction();
        Student dbStudent = getEntityManager().merge(updatedStudent);
        getEntityManager().lock(dbStudent, LockModeType.OPTIMISTIC);
        commitTransaction();
        getEntityManager().close();
        return dbStudent;
    }

    @Override
    public void remove(Student student) {
        beginTransaction();
        getEntityManager().remove(student);
        commitTransaction();
        getEntityManager().close();
    }

    @Override
    public Optional<Student> findById(Integer id) {
        beginTransaction(); // After applying
        Optional<Student> student = Optional.ofNullable(getEntityManager().find(Student.class, id,LockModeType.OPTIMISTIC));
        commitTransaction();
        return student;
    }

    @Override
    public Optional<Student> findByEmail(String email) throws NoResultException, NonUniqueResultException{  // Q. is it valid to handle exception that will occur if query fails ?
        beginTransaction();
        TypedQuery<Student> studentByEmail = getEntityManager().createQuery("select e from Student e where e.studentEmail =: email", Student.class);
        studentByEmail.setParameter("email",email);
        Student singleResult = studentByEmail.getSingleResult(); // throws exception
        commitTransaction();
        return Optional.ofNullable(singleResult);
    }

    @Override
    public List<Student> findAll() {
        beginTransaction();
        TypedQuery<Student> allStudents = getEntityManager().createQuery("select e from Student e", Student.class);
        commitTransaction();
        return allStudents.getResultList();
    }



    @Override
    public List<StudentCourse> findStudentsCourseById(Integer studentId) {
        beginTransaction();
        Student student = getEntityManager().find(Student.class, studentId);
        List<StudentCourse> courses = student.getStudentCourses();
        commitTransaction();
        return courses;
    }


}
