package com.scm.repositoryimpl;

import com.scm.entity.StudentCourse;
import com.scm.entitymanager.EntityManagerUtilityClass;
import com.scm.repository.AdminRepository;
import jakarta.persistence.*;

import java.util.Optional;

public class AdminRepositoryImpl implements AdminRepository {

    private final EntityManagerFactory entityManagerFactory = EntityManagerUtilityClass.getEntityManagerFactoryInstance();
    private EntityManager entityManager ;

    private  EntityManager getEntityManager(){
        if(entityManager == null || !entityManager.isOpen() ){
            entityManager = entityManagerFactory.createEntityManager();
        }
        return entityManager;
    }

    private void beginTransaction(){
        getEntityManager().getTransaction().begin();
    }

    private void commitTransaction(){
        getEntityManager().getTransaction().commit();
    }



    @Override
    public void registerCourse(StudentCourse studentCourse) {
        beginTransaction();
        getEntityManager().persist(studentCourse);
        commitTransaction();
        getEntityManager().close();
    }

    @Override
    public Optional<StudentCourse> findById(Integer studentId, Integer courseId) throws NoResultException, NonUniqueResultException {
        TypedQuery<StudentCourse> query = getEntityManager().createQuery("SELECT e FROM StudentCourse e where e.student.id =:sid AND e.course.id =:cid", StudentCourse.class);
        query.setParameter("sid", studentId);
        query.setParameter("cid", courseId);
        StudentCourse singleResult = query.getSingleResult();
        return Optional.ofNullable(singleResult);

    }

    @Override
    public void deleteStudentCourseRegistration(StudentCourse studentCourse) {
        beginTransaction();
        getEntityManager().remove(studentCourse);
        commitTransaction();
        getEntityManager().close();
    }

    @Override
    public Long findCountOfRegistration(Integer courseId) {
        TypedQuery<Long> query = getEntityManager().createQuery("SELECT COUNT(s) FROM StudentCourse  s WHERE s.course.id =:courseId", Long.class);
        query.setParameter("courseId", courseId);
        return query.getSingleResult();
    }
}
