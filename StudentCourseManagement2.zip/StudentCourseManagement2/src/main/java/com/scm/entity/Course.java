package com.scm.entity;

import jakarta.persistence.*;

import java.util.*;

@Entity
@Table(name = "course", schema = "institute")
@SequenceGenerator(name = "entity_sequence_generation", sequenceName = "course_id_generator", allocationSize = 1)
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entity_sequence_generation")
    private Integer id;
    @Column(name = "name", nullable = false, unique = true)
    private String courseName;
    @Column(name = "duration", nullable = false)
    private String courseDuration;
    @Column(name = "price", nullable = false)
    private Long coursePrice;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "trainer_name",schema = "institute", joinColumns = @JoinColumn(name = "course_id"))
    @Column(name = "trainer_name")
    private Set<String> trainers;

    @Version
    private Integer version;


    @OneToMany(mappedBy = "course", cascade = CascadeType.REFRESH)
    private List<StudentCourse> studentCourses = new ArrayList<>();


    public Course(String courseName, String courseDuration, Long coursePrice, Set<String> trainers) {
        this.courseName = courseName;
        this.courseDuration = courseDuration;
        this.coursePrice = coursePrice;
        this.trainers = trainers;
    }

    public Course(Integer id, String courseName, String courseDuration, Long coursePrice, Set<String> trainers) {
        this.id = id;
        this.courseName = courseName;
        this.courseDuration = courseDuration;
        this.coursePrice = coursePrice;
        this.trainers = trainers;
    }

    public Course(Integer id, String courseName, String courseDuration, Long coursePrice, Set<String> trainers, Integer version) {
        this.id = id;
        this.courseName = courseName;
        this.courseDuration = courseDuration;
        this.coursePrice = coursePrice;
        this.trainers = trainers;
        this.version = version;
    }

    public Course() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer courseId) {
        this.id = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public Long getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(Long coursePrice) {
        this.coursePrice = coursePrice;
    }

    public Set<String> getTrainers() {
        return trainers;
    }

    public void setTrainers(Set<String> trainers) {
        this.trainers = trainers;
    }

    public List<StudentCourse> getStudentCourses() {
        return studentCourses;
    }

    public void setStudentCourses(List<StudentCourse> studentCourses) {
        this.studentCourses = studentCourses;
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", courseName='" + courseName + '\'' +
                ", courseDuration='" + courseDuration + '\'' +
                ", coursePrice=" + coursePrice +
                ", trainers=" + trainers +
                ", version=" + version +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Course course)) return false;
        return Objects.equals(id, course.id) && Objects.equals(courseName, course.courseName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, courseName);
    }
}
