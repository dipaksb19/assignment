package com.scm.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "aadhar")
public class Aadhar {

    @Id
    private Integer id;

    @Column(name = "adhar_number", unique = true)
    private String aadharNumber;

    @OneToOne()
    @MapsId
    @JoinColumn(name = "id")
    private Student student;


    public Aadhar(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public Aadhar() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAadharNumber() {
        return aadharNumber;
    }

    public void setAadharNumber(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public String toString() {
        return "Aadhar{" +
                "aadharNumber='" + aadharNumber + '\'' +
                '}';
    }
}
