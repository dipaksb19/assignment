package com.scm.entity;

import jakarta.persistence.*;

import java.util.*;


@Entity
@Table(name = "student", schema = "institute")
@SequenceGenerator(name = "entity_sequence_generation", sequenceName = "scms_id_generator", allocationSize = 1)
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entity_sequence_generation")
    private Integer id;
    @Column(name ="name", nullable = false)
    private String studentName;
    @Column(name ="email", nullable = false, unique = true)
    private String studentEmail;
    @Column(name = "department", nullable = false)
    private String studentDepartment;

    @ElementCollection
    @CollectionTable(name = "phone_numbers",schema = "institute", joinColumns = @JoinColumn(name = "student_id"))
    @Column(name = "phone_no")
    private Set<String> phoneNumber;

    @Version
    Integer version;

    @Embedded
    Address address;

    @OneToMany(mappedBy = "student", cascade = {CascadeType.REMOVE,CascadeType.REFRESH})
    private List<StudentCourse> studentCourses = new ArrayList<>();

    public Student(String studentName, String studentEmail, String studentDepartment, Set<String> phoneNumber, Address address) {
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentDepartment = studentDepartment;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public Student(Integer id, String studentName, String studentEmail, String studentDepartment, Set<String> phoneNumber, Address address) {
        this.id = id;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentDepartment = studentDepartment;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public Student(Integer id, Address address) {
        this.id = id;
        this.address = address;
    }


    public Student(Integer id, String studentEmail, String studentName, String studentDepartment, Set<String> phoneNumber, Integer version, Address address) {
        this.id = id;
        this.studentEmail = studentEmail;
        this.studentName = studentName;
        this.studentDepartment = studentDepartment;
        this.phoneNumber = phoneNumber;
        this.version = version;
        this.address = address;
    }

    public Student(Integer id, Set<String> phoneNumber) {
        this.id = id;
        this.phoneNumber = phoneNumber;
    }

    public Student() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer studentId) {
        this.id = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentDepartment() {
        return studentDepartment;
    }

    public void setStudentDepartment(String studentDepartment) {
        this.studentDepartment = studentDepartment;
    }

    public Set<String> getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Set<String> phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public List<StudentCourse> getStudentCourses() {
        return studentCourses;
    }

    public void setStudentCourses(List<StudentCourse> studentCourses) {
        this.studentCourses = studentCourses;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", studentName='" + studentName + '\'' +
                ", studentEmail='" + studentEmail + '\'' +
                ", studentDepartment='" + studentDepartment + '\'' +
                ", phoneNumber=" + phoneNumber +
            //    ", version=" + version +
            //    "\n\t\t\t\t, " + address +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Student student)) return false;
        return Objects.equals(id, student.id) && Objects.equals(studentEmail, student.studentEmail);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, studentEmail);
    }
}
