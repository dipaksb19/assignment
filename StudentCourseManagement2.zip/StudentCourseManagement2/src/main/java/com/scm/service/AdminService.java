package com.scm.service;

import com.scm.entity.StudentCourse;

public interface AdminService {

    void registerCourse(StudentCourse studentCourse);

    void deregisterStudentCourse(StudentCourse studentCourse);

    Long countOfRegistrationOfCourse(Integer courseId);
}
