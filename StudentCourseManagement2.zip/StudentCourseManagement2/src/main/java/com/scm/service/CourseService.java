package com.scm.service;


import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;

import java.util.List;
import java.util.Set;

public interface CourseService {

    Course registerNewCourse(Course newCourse);

    Course updateCourse(Course updatedCourse);

    void removeCourse(Integer courseId);

    Course getById(Integer courseId);

    Course getByName(String courseName);

    List<Course> getAllCourses();

    List<StudentCourse> getStudentsByCourse(Integer courseId);
}
