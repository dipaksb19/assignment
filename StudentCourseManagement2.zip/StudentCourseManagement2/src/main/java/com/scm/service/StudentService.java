package com.scm.service;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;

import java.util.List;
import java.util.Set;

public interface StudentService {

    Student registerNewStudent(Student newStudent);

    Student updateStudent(Student updatedStudent);

    Student addNewNumber(Student student);

    Student updateAddress(Student updatedStudent);

    void removeStudent(Integer studentId);

    Student getById(Integer studentId);

    Student getByEmail(String studentEmail);

    List<Student> getAllStudents();

    List<StudentCourse> getStudentsCourseById(Integer studentId);



}
