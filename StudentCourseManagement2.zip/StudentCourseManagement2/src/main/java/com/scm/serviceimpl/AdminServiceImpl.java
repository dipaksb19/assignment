package com.scm.serviceimpl;

import com.scm.entity.Course;
import com.scm.entity.StudentCourse;
import com.scm.exception.CourseDoesNotExistException;
import com.scm.exception.NonUniqueResultFoundException;
import com.scm.exception.StudentAlreadyRegisteredWithCourseException;
import com.scm.exception.StudentDoesNotHaveCourseRegistrationException;
import com.scm.repository.AdminRepository;
import com.scm.repository.CourseRepository;
import com.scm.repositoryimpl.AdminRepositoryImpl;
import com.scm.repositoryimpl.CourseRepositoryImpl;
import com.scm.service.AdminService;
import jakarta.persistence.NoResultException;
import jakarta.persistence.NonUniqueResultException;


import java.util.Optional;

public class AdminServiceImpl implements AdminService {

    private AdminRepository adminRepository = new AdminRepositoryImpl();

    private CourseRepository courseRepository = new CourseRepositoryImpl();

    @Override
    public void registerCourse(StudentCourse studentCourse) {
        Optional<StudentCourse> existingCourse = Optional.empty();
        try{
           existingCourse  = adminRepository.findById(studentCourse.getStudent().getId(), studentCourse.getCourse().getId());
        }catch(NoResultException e){
            adminRepository.registerCourse(studentCourse);
        }catch(NonUniqueResultException e){
            throw new NonUniqueResultFoundException("Non Unique Result Exist");
        }
        if(existingCourse.isPresent()){
            throw new StudentAlreadyRegisteredWithCourseException("Student already registered with course id - " + studentCourse.getCourse().getId());
        }
    }

    @Override
    public void deregisterStudentCourse(StudentCourse studentCourse) {
        Optional<StudentCourse> existingStudentCourse;
        try{
            existingStudentCourse = adminRepository.findById(studentCourse.getStudent().getId(), studentCourse.getCourse().getId());
        }catch (NoResultException e){
            throw  new StudentDoesNotHaveCourseRegistrationException("Student does not have registered with course id - " + studentCourse.getCourse().getId());
        }catch(NonUniqueResultException e){
            throw new NonUniqueResultFoundException("Non Unique Result Exist");
        }
        if(existingStudentCourse.isEmpty()){
            throw new StudentDoesNotHaveCourseRegistrationException("Student does not have registered with course id - " + studentCourse.getCourse().getId());
        }
        adminRepository.deleteStudentCourseRegistration(existingStudentCourse.get());
    }

    @Override
    public Long countOfRegistrationOfCourse(Integer courseId) {
        Optional<Course> existingCourse = courseRepository.findById(courseId);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course Does Not Exist With Id - " + courseId);
        }
        return adminRepository.findCountOfRegistration(courseId);
    }
}
