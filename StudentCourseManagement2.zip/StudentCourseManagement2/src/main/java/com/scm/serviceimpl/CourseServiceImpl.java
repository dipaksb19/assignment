package com.scm.serviceimpl;

import com.scm.entity.Course;
import com.scm.entity.StudentCourse;
import com.scm.exception.*;
import com.scm.repository.CourseRepository;
import com.scm.repositoryimpl.CourseRepositoryImpl;
import com.scm.service.CourseService;
import com.scm.serviceimpl.validate.CourseValidator;
import jakarta.persistence.NoResultException;
import jakarta.persistence.NonUniqueResultException;

import java.util.List;
import java.util.Optional;

public class CourseServiceImpl implements CourseService {

    private CourseRepository courseRepository = new CourseRepositoryImpl();


    @Override
    public Course registerNewCourse(Course newCourse) {
        CourseValidator.validate(newCourse);
        Optional<Course> existingCourse = Optional.empty();
        try{
            existingCourse = courseRepository.findByName(newCourse.getCourseName());
        }catch(NoResultException e){
            newCourse =  courseRepository.save(newCourse);
        }catch(NonUniqueResultException e){
            throw new NonUniqueResultFoundException("Mulltiple Courses Found By Same Course Name - " + newCourse.getCourseName());
        }
        if(existingCourse.isPresent()){
            throw new CourseAlreadyExistException("Course already exist with name - " + newCourse.getCourseName());
        }
        return newCourse;
    }

    @Override
    public Course updateCourse(Course updatedCourse) {
        Optional<Course> existingCourse = courseRepository.findById(updatedCourse.getId());
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with id - " + updatedCourse.getId());
        }
        existingCourse.get().setCourseName(updatedCourse.getCourseName());
        existingCourse.get().setCourseDuration(updatedCourse.getCourseDuration());
        existingCourse.get().setCoursePrice(updatedCourse.getCoursePrice());
        existingCourse.get().setTrainers(updatedCourse.getTrainers());
        return courseRepository.update(existingCourse.get());
    }

    @Override
    public void removeCourse(Integer courseId) {
        Optional<Course> existingCourse = courseRepository.findById(courseId);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with id - " + courseId);
        }
        courseRepository.remove(existingCourse.get());
    }

    @Override
    public Course getById(Integer courseId) {
        Optional<Course> existingCourse = courseRepository.findById(courseId);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with id - " + courseId);
        }
        return existingCourse.get();
    }

    @Override
    public Course getByName(String courseName) {
        Optional<Course> existingCourse;
        try{
            existingCourse = courseRepository.findByName(courseName);
        }catch(NoResultException e){
            throw new CourseDoesNotExistException("Course does not found with name - " + courseName);
        }catch(NonUniqueResultException e){
            throw new NonUniqueResultFoundException("Multiple records found by name - " + courseName);
        }
        return existingCourse.get();
    }

    @Override
    public List<Course> getAllCourses() {
        List<Course> allCourses = courseRepository.findAll();
        return allCourses
                .stream()
                .sorted((x,y) -> Math.toIntExact(x.getCoursePrice() - y.getCoursePrice()))
                .toList();
    }

    @Override
    public List<StudentCourse> getStudentsByCourse(Integer courseId) {
        Optional<Course> existingCourse = courseRepository.findById(courseId);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course Does Not Exist With Id - " + courseId);
        }
        List<StudentCourse> studentsByCourse = courseRepository.findStudentsByCourse(courseId);
        if(studentsByCourse.isEmpty()){
            throw new CourseDoesNotHaveRegistrationException("Course is not registered by any student, course id - " + courseId);
        }
        return studentsByCourse.stream()
                .sorted((x, y) -> x.getStudent().getStudentName().compareTo(y.getStudent().getStudentName()))
                .toList();
    }
}
