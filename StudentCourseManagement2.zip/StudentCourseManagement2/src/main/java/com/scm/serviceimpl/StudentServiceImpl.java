package com.scm.serviceimpl;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.entity.StudentCourse;
import com.scm.exception.*;
import com.scm.repository.StudentRepository;
import com.scm.repositoryimpl.StudentRepositoryImpl;
import com.scm.service.StudentService;
import com.scm.serviceimpl.validate.StudentValidator;
import jakarta.persistence.NoResultException;
import jakarta.persistence.NonUniqueResultException;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;


public class StudentServiceImpl implements StudentService {

    private StudentRepository studentRepository = new StudentRepositoryImpl();


    @Override
    public Student registerNewStudent(Student newStudent) {
        StudentValidator.validate(newStudent); // feilds validation and email validation
        // for new student id will not be there so no need to check id
        Optional<Student> existingStudent = Optional.empty();
        try{
            existingStudent = studentRepository.findByEmail(newStudent.getStudentEmail());
        }catch(NoResultException e){
            newStudent = studentRepository.save(newStudent);
        }catch (NonUniqueResultException e){
            throw new NonUniqueResultFoundException("Multiple Result Found with email id - " + newStudent.getStudentEmail());
        }
        if(existingStudent.isPresent()){ // checking email already exist or not
            throw new StudentAlreadyExistException("Student already exist by email - " + newStudent.getStudentEmail());
        }
        return newStudent;
    }

    @Override
    public Student updateStudent(Student updatedStudent) {
        if(!StudentValidator.isValidEmail(updatedStudent.getStudentEmail())){
            throw new InvalidInputEnteredException("Email");
        }
        Optional<Student> existingStudent = studentRepository.findById(updatedStudent.getId());
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + updatedStudent.getId());
        }
        existingStudent.get().setStudentName(updatedStudent.getStudentName());
        existingStudent.get().setStudentEmail(updatedStudent.getStudentEmail());
        existingStudent.get().setStudentDepartment(updatedStudent.getStudentDepartment());
        existingStudent.get().setAddress(updatedStudent.getAddress());
        existingStudent.get().setPhoneNumber(updatedStudent.getPhoneNumber());
        return studentRepository.update(existingStudent.get());
    }


    @Override
    public Student updateAddress(Student updatedStudent) {
        Optional<Student> existingStudent = studentRepository.findById(updatedStudent.getId());
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + updatedStudent.getId());
        }
        existingStudent.get().setAddress(updatedStudent.getAddress());
        return studentRepository.update(existingStudent.get());
    }


    @Override
    public Student addNewNumber(Student updatedStudent) {
        Optional<Student> existingStudent = studentRepository.findById(updatedStudent.getId());
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + updatedStudent.getId());
        }
        Set<String> existingPhoneNumber = existingStudent.get().getPhoneNumber();
        existingPhoneNumber.addAll(updatedStudent.getPhoneNumber());
        existingStudent.get().setPhoneNumber(existingPhoneNumber);
        return studentRepository.update(existingStudent.get());
    }


    @Override
    public void removeStudent(Integer studentId) {
        Optional<Student> existingStudent = studentRepository.findById(studentId);
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + studentId);
        }
        studentRepository.remove(existingStudent.get());
    }

    @Override
    public Student getById(Integer studentId) {
        Optional<Student> databaseStudent = studentRepository.findById(studentId);
        if(databaseStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + studentId);
        }
        return databaseStudent.get();
    }

    @Override
    public Student getByEmail(String studentEmail) {
        if(!StudentValidator.isValidEmail(studentEmail)){
            throw new InvalidInputEnteredException("Email");
        }
        Optional<Student> existingStudent;
        try{
            existingStudent = studentRepository.findByEmail(studentEmail);
            return existingStudent.get();
        }catch(NoResultException e){
            throw new StudentDoesNotExistException("Student does not exist with email id - " + studentEmail);
        }catch(NonUniqueResultException e){
            throw new NonUniqueResultFoundException("Multiple Result found with email id - " + studentEmail);
        }
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> allStudents = studentRepository.findAll()
                .stream()
                .sorted(Comparator.comparing(Student::getStudentName))
                .toList();
        return allStudents;
    }


    @Override
    public List<StudentCourse> getStudentsCourseById(Integer studentId) {
        Optional<Student> existingStudent = studentRepository.findById(studentId);
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student Does Not Exist With Id - " + studentId);
        }
        List<StudentCourse> studentsCourseById = studentRepository.findStudentsCourseById(studentId);
        if(studentsCourseById.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with student id - " + studentId);
        }
        return studentsCourseById;
    }


}
