package com.scm.exception;

public class StudentDoesNotHaveCourseRegistrationException extends RuntimeException{
    public StudentDoesNotHaveCourseRegistrationException(String message) {
        super(message);
    }
}
