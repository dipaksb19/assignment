package com.scm.exception;

public class CourseDoesNotHaveRegistrationException extends RuntimeException{

    public CourseDoesNotHaveRegistrationException(String message) {
        super(message);
    }
}
