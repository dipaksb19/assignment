package com.scm.exception;

public class CourseExistWithRelationshipException extends RuntimeException{
    public CourseExistWithRelationshipException() {
        super("Course exist with students Registration");
    }
}
