package com.scm.exception;

public class StudentAlreadyRegisteredWithCourseException extends RuntimeException{
    public StudentAlreadyRegisteredWithCourseException(String message) {
        super(message);
    }
}
