package com.scm.exception;

public class NonUniqueResultFoundException extends RuntimeException{
    public NonUniqueResultFoundException(String message) {
        super(message);
    }
}
