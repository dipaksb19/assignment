package com.scm;

import com.scm.entity.*;
import com.scm.service.AdminService;
import com.scm.service.CourseService;
import com.scm.service.StudentService;
import com.scm.serviceimpl.AdminServiceImpl;
import com.scm.serviceimpl.CourseServiceImpl;
import com.scm.serviceimpl.StudentServiceImpl;


import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class MyApp {
    public static void main(String[] args) {

        StudentService student = new StudentServiceImpl();
        CourseService course = new CourseServiceImpl();
        AdminService admin = new AdminServiceImpl();


        Scanner sc = new Scanner(System.in);
        System.out.println("\t\t----- Student Course Management System -----");
        System.out.println("Home --->");
        System.out.println("Enter 1 to start");
        System.out.println("Enter Here : ");
        int start = sc.nextInt();

        while(start == 1){

            System.out.println("Select below option :");
            System.out.println("1. Go to Student \n2. Go to Course\n3. Go to Admin");
            System.out.println("Enter Here : ");
            int option = sc.nextInt();

            if(option == 1){
                // student
                System.out.println("Student Section --->");
                while(start == 1){
                    System.out.println("\nSelect Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Student\n2. Update Existing Student\n3. Delete Student by Id\n4. Get Student by Id\n5. Get Student by Email\n6. Get All Available Students\n7. Update Address\n8. Add phone number\n9. Get Student Course By Id\n");
                    System.out.println("Enter Option Here : ");
                    int studentOperation = sc.nextInt();

                    switch (studentOperation){
                        case 1:
                            // Register student
                            System.out.println("Enter Student Details : ");
                            System.out.println("Enter Name : ");
                            String name = sc.next();
                            sc.nextLine();
                            System.out.println("Enter Email :");
                            String email = sc.nextLine();
                            System.out.println("Enter Department : ");
                            String department = sc.nextLine();
                            System.out.println("Enter Street :");
                            String street = sc.nextLine();
                            System.out.println("Enter city : ");
                            String city = sc.nextLine();
                            System.out.println("Enter State :");
                            String state = sc.nextLine();
                            System.out.println("Enter Country : ");
                            String country = sc.nextLine();
                            System.out.println("Enter Pincode : ");
                            String pinCode = sc.nextLine();
                            System.out.println("Enter Phone Number : ");
                            Set<String> contacts = new HashSet<>();
                            String phoneNumber = sc.nextLine();
                            contacts.add(phoneNumber);
                            System.out.println(student.registerNewStudent(new Student(name, email, department, contacts, new Address(street, city, state, country, pinCode))));
                            break;

                        case 2 :
                            // Update Student
                            System.out.println("Enter detail to Update Student : ");
                            System.out.println("Enter Existing Student's id : ");
                            int studentIdToUpdate = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Student Name : ");
                            String studentName = sc.nextLine();
                            System.out.println("Enter Student Email : ");
                            String studentUpdatedEmail = sc.nextLine();
                            System.out.println("Enter Student Department : ");
                            String studentDepartment = sc.nextLine();
                            System.out.println("Enter Street :");
                            String streetToUpdate = sc.nextLine();
                            System.out.println("Enter city : ");
                            String cityToUpdate = sc.nextLine();
                            System.out.println("Enter State :");
                            String stateToUpdate = sc.nextLine();
                            System.out.println("Enter Country : ");
                            String countryToUpdate = sc.nextLine();
                            System.out.println("Enter Pincode : ");
                            String pinCodeToUpdate = sc.nextLine();
                            System.out.println("Enter Number : ");
                            String contactNumber = sc.nextLine();
                            Set<String> studentContacts = new HashSet<>();
                            studentContacts.add(contactNumber);
                            System.out.println(student.updateStudent(new Student(studentIdToUpdate, studentName, studentUpdatedEmail, studentDepartment,studentContacts, new Address(streetToUpdate, cityToUpdate, stateToUpdate, countryToUpdate, pinCodeToUpdate))));
                            break;

                        case 3 :
                            // Delete Student By Id
                            System.out.println("Enter Student Id : ");
                            int studentIdToDelete = sc.nextInt();
                            student.removeStudent(studentIdToDelete);
                            break;

                        case 4 :
                            // Find Student By Id
                            System.out.println("Enter Student Id : ");
                            int studentId = sc.nextInt();
                            System.out.println(student.getById(studentId));
                            break;

                        case 5 :
                            // Find Student by email
                            System.out.println("Enter Student Email : ");
                            String studentEmail = sc.next();
                            System.out.println(student.getByEmail(studentEmail));
                            break;
                        case 6 :
                            // Find All Students Available in Database
                            List<Student> allStudents = student.getAllStudents();
                            for(Student eachStudent : allStudents){
                                System.out.println(eachStudent);
                            }
                            break;

                        case 7 :
                            // Update Student address
                            System.out.println("Enter Details to update Student Address : ");
                            System.out.println("Enter Existing Student's id : ");
                            int existingStudentId = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Street :");
                            String streetsToUpdate = sc.nextLine();
                            System.out.println("Enter city : ");
                            String citysToUpdate = sc.nextLine();
                            System.out.println("Enter State :");
                            String statesToUpdate = sc.nextLine();
                            System.out.println("Enter Country : ");
                            String countrysToUpdate = sc.nextLine();
                            System.out.println("Enter Pincode : ");
                            String pinCodesToUpdate = sc.nextLine();
                            System.out.println(student.updateAddress(new Student(existingStudentId,new Address(streetsToUpdate,citysToUpdate,statesToUpdate,countrysToUpdate,pinCodesToUpdate))));
                            break;
                        case 8 :
                            // Add Phone Numbers
                            System.out.println("Enter Existing Student's Id : ");
                            int existingStudentIds = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Phone Number : ");
                            String newPhoneNumber = sc.nextLine();
                            Set<String> newPhoneNumbers = new HashSet<>();
                            newPhoneNumbers.add(newPhoneNumber);
                            System.out.println(student.addNewNumber(new Student(existingStudentIds, newPhoneNumbers)));
                            break;
                        case 9 :
                            // get student course
                            System.out.println("Enter The Student Id : ");
                            int studentIdToGetCourse = sc.nextInt();
                            List<StudentCourse> studentsCourseById = student.getStudentsCourseById(studentIdToGetCourse);
                            for(StudentCourse studentsCours : studentsCourseById){
                                System.out.println( studentsCours.getCourse().getId() + " : " + studentsCours.getCourse().getCourseName());
                            }
                            break;

                        default:
                            // Exit from student section
                            start = 0;
                            System.out.println("Exited from student !");
                    }
                }
            }else if(option == 2){
                // course
                System.out.println("Course Section --->");
                while(start == 1){
                    System.out.println("Select Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Course\n2. Update Existing Course\n3. Delete Existing Course\n4. Get Course By Id\n5. Get Course by Name\n6. Get All Available Courses\n7. Get Students of Course by course Id");
                    System.out.println("Enter Option Here : ");
                    int courseOperation = sc.nextInt();

                    switch(courseOperation){
                        case 1 :
                            // Register for new course
                            System.out.println("Enter course details :");
                            sc.nextLine();
                            System.out.println("Enter course name : ");
                            String name = sc.nextLine();
                            System.out.println("Enter Duration : ");
                            String duration = sc.nextLine();
                            System.out.println("Course Fees : ");
                            long fees = sc.nextLong();
                            sc.nextLine();
                            System.out.println("Enter Trainer name : ");
                            String trainerName = sc.nextLine();
                            Set<String> trainer = new HashSet<>();
                            trainer.add(trainerName);
                            System.out.println(course.registerNewCourse(new Course(name, duration, fees, trainer)));
                            break;

                        case 2 :
                            // update course
                            System.out.println("Enter detail to Update Course :");
                            System.out.println("Enter Existing Course id : ");
                            int existingCourseId = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Course Name : ");
                            String updatedCourseName = sc.nextLine();
                            System.out.println("Enter Duration : ");
                            String updatedCourseDuration = sc.nextLine();
                            System.out.println("Enter Course Fees : ");
                            long updatedCourseFees = sc.nextLong();
                            sc.nextLine();
                            System.out.println("Enter Trainer name : ");
                            String trainersName = sc.nextLine();
                            Set<String> trainers = new HashSet<>();
                            trainers.add(trainersName);
                            System.out.println(course.updateCourse(new Course(existingCourseId, updatedCourseName, updatedCourseDuration, updatedCourseFees, trainers)));
                            break;

                        case 3 :
                            // delete course
                            System.out.println("Enter Course Id : ");
                            int courseIdToDelete = sc.nextInt();
                            course.removeCourse(courseIdToDelete);
                            break;

                        case 4 :
                            // Get course by id
                            System.out.println("Enter course id : ");
                            int courseId = sc.nextInt();
                            System.out.println(course.getById(courseId));
                            break;

                        case 5 :
                            // Get Course by Name
                            System.out.println("Enter Course Name : ");
                            String courseName = sc.next();
                            System.out.println(course.getByName(courseName));
                            break;

                        case 6 :
                            // find all courses
                            List<Course> allCourses = course.getAllCourses();
                            for(Course eachCourse : allCourses){
                                System.out.println(eachCourse);
                            }
                            break;

                        case 7 :
                            // Get course associated students
                            System.out.println("Enter the course id : ");
                            int courseIdToGet = sc.nextInt();
                            List<StudentCourse> studentsByCourse = course.getStudentsByCourse(courseIdToGet);
                            System.out.println("Students Id and Name :");
                            for (StudentCourse student1 :studentsByCourse ) {
                                System.out.println(student1.getStudent().getId() + " : " + student1.getStudent().getStudentName());
                            }
                            break;

                        default:
                            // default to exit from course section
                            start = 0;
                            System.out.println("Exited from Course !");

                    }
                }

            } else if (option == 3) {
                // Admin
                System.out.println("Admin Section --->");
                while(start == 1){
                    System.out.println("Select Option from below menu :");
                    System.out.println("0. Exit \n1. Enroll Student With Course\n2. UnEnroll Student with Course\n3. Get Count of Registration By Course");
                    System.out.println("Enter Option Here : ");
                    int courseOperation = sc.nextInt();

                    switch(courseOperation){
                        case 1 :
                            // Register for course
                            System.out.println("Select Student From Below to Enroll : ");
                            List<Student> allStudents = student.getAllStudents();
                            int index1 = 0;
                            for(Student student1 : allStudents){
                                System.out.println("Option : " + index1 + " - " + student1.getStudentName() + ",  " + student1.getStudentDepartment() + ",  " + student1.getStudentEmail() + ",  " + student1.getPhoneNumber());
                                index1++;
                            }
                            System.out.println("Enter Option : ");
                            int option1 = sc.nextInt();
                            Student studentToRegister = allStudents.get(option1);
                            System.out.println("Select Course From Below : ");
                            List<Course> courses = course.getAllCourses();
                            int index2 = 0;
                            for(Course course1 : courses){
                                System.out.println("Option : " + index2 + " - " + course1.getCourseName() + ",  " + course1.getCourseDuration() + ",  " + course1.getCoursePrice());
                                index2++;
                            }
                            System.out.println("Enter Option : ");
                            int option2 = sc.nextInt();
                            Course courseToRegister = courses.get(option2);
                            sc.nextLine();
                            System.out.println("Enter Admin UserName : ");
                            String userName = sc.nextLine();
                            admin.registerCourse(new StudentCourse(studentToRegister,courseToRegister,userName));
                            break;
                        case 2 :
                            // Unenroll Student With Course
                            System.out.println("Select Student From Below to Un-Enroll : ");
                            List<Student> allStudents2 = student.getAllStudents();
                            int index3 = 0;
                            for(Student student1 : allStudents2){
                                System.out.println("Option : " + index3 + " - " + student1.getStudentName() + ",  " + student1.getStudentDepartment() + ",  " + student1.getStudentEmail() + ",  " + student1.getPhoneNumber());
                                index3++;
                            }
                            System.out.println("Enter Option : ");
                            int option3 = sc.nextInt();
                            Student studentToUnEnroll = allStudents2.get(option3);
                            System.out.println("Select Course From Below : ");
                            List<Course> courses3 = course.getAllCourses();
                            int index4 = 0;
                            for(Course course1 : courses3){
                                System.out.println("Option : " + index4 + " - " + course1);
                                index4++;
                            }
                            System.out.println("Enter Option : ");
                            int option4 = sc.nextInt();
                            Course courseToUnEnroll = courses3.get(option4);
                            admin.deregisterStudentCourse(new StudentCourse(studentToUnEnroll,courseToUnEnroll));
                            break;
                        case 3 :
                            // Get Count of Registration by course
                            System.out.println("Enter the Course Id : ");
                            int courseId = sc.nextInt();
                            System.out.println("Count of Registration : " + admin.countOfRegistrationOfCourse(courseId));
                            break;
                        default:
                            // default to exit from course section
                            start = 0;
                            System.out.println("Exited from Course !");

                    }
                }
            } else{
                System.out.println("Invalid Input Entered !");
            }

            System.out.println("Home --->");
            System.out.println("1. to continue \n2. to Stope");
            System.out.println("Enter Here : ");
            start = sc.nextInt();
        }
        System.out.println("--- Application Stopped ---");

    }
}


















































 /*

        Scanner sc = new Scanner(System.in);
        System.out.println("\t\t----- Student Course Management System -----");
        System.out.println("Home --->");
        System.out.println("Enter 1 to start");
        System.out.println("Enter Here : ");
        int start = sc.nextInt();

        while(start == 1){

            System.out.println("Select below option :");
            System.out.println("1. Go to Student \n2. Go to Course");
            System.out.println("Enter Here : ");
            int option = sc.nextInt();

            if(option == 1){
                // student
                System.out.println("Student Section --->");
                while(start == 1){
                    System.out.println("\nSelect Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Student\n2. Update Existing Student\n3. Delete Student by Id\n4. Get Student by Id\n5. Get Student by Email\n6. Get All Available Students\n7. Update Address\n8. Add phone number");
                    System.out.println("Enter Option Here : ");
                    int studentOperation = sc.nextInt();

                    switch (studentOperation){
                        case 1:
                            // Register student
                            System.out.println("Enter Student Details : ");
                            System.out.println("Enter Name : ");
                            String name = sc.next();
                            sc.nextLine();
                            System.out.println("Enter Email :");
                            String email = sc.nextLine();
                            System.out.println("Enter Department : ");
                            String department = sc.nextLine();
                            System.out.println("Enter Street :");
                            String street = sc.nextLine();
                            System.out.println("Enter city : ");
                            String city = sc.nextLine();
                            System.out.println("Enter State :");
                            String state = sc.nextLine();
                            System.out.println("Enter Country : ");
                            String country = sc.nextLine();
                            System.out.println("Enter Pincode : ");
                            String pinCode = sc.nextLine();
                            System.out.println("Enter Phone Number : ");
                            Set<String> contacts = new HashSet<>();
                            String phoneNumber = sc.nextLine();
                            contacts.add(phoneNumber);
                            List<Course> allCourses = course.getAllCourses();
                            int courseIndex = 0;
                            System.out.println("Select Course From Below To Enroll : ");
                            for (Course eachCourse : allCourses) {
                                System.out.println("option : " + courseIndex + " - " + eachCourse);
                                courseIndex++;
                            }
                            System.out.println("Enter course option : ");
                            int index = sc.nextInt();
                            Set<Course> selectedCourse = new HashSet<>();
                            selectedCourse.add(allCourses.get(index));
                            System.out.println(student.registerNewStudent(new Student(name, email, department, contacts, new Address(street, city, state, country, pinCode), selectedCourse)));
                            break;

                        case 2 :
                            // Update Student
                            System.out.println("Enter detail to Update Student : ");
                            System.out.println("Enter Existing Student's id : ");
                            int studentIdToUpdate = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Student Name : ");
                            String studentName = sc.nextLine();
                            System.out.println("Enter Student Email : ");
                            String studentUpdatedEmail = sc.nextLine();
                            System.out.println("Enter Student Department : ");
                            String studentDepartment = sc.nextLine();
                            System.out.println("Enter Street :");
                            String streetToUpdate = sc.nextLine();
                            System.out.println("Enter city : ");
                            String cityToUpdate = sc.nextLine();
                            System.out.println("Enter State :");
                            String stateToUpdate = sc.nextLine();
                            System.out.println("Enter Country : ");
                            String countryToUpdate = sc.nextLine();
                            System.out.println("Enter Pincode : ");
                            String pinCodeToUpdate = sc.nextLine();
                            System.out.println("Enter Number : ");
                            String contactNumber = sc.nextLine();
                            Set<String> contacts = new HashSet<>();
                            contacts.add(contactNumber);
                            System.out.println(student.updateStudent(new Student(studentIdToUpdate, studentName, studentUpdatedEmail, studentDepartment,contacts, new Address(streetToUpdate, cityToUpdate, stateToUpdate, countryToUpdate, pinCodeToUpdate))));
                            break;

                        case 3 :
                            // Delete Student By Id
                            System.out.println("Enter Student id : ");
                            int studentIdToDelete = sc.nextInt();
                            student.removeStudent(studentIdToDelete);
                            break;

                        case 4 :
                            // Find Student By Id
                            System.out.println("Enter Student id : ");
                            int studentId = sc.nextInt();
                            System.out.println(student.getById(studentId));
                            break;

                        case 5 :
                            // Find Student by email
                            System.out.println("Enter Student Email : ");
                            String studentEmail = sc.next();
                            System.out.println(student.getByEmail(studentEmail));
                            break;
                        case 6 :
                            // Find All Students Available in Database
                            List<Student> allStudents = student.getAllStudents();
                            for(Student eachStudent : allStudents){
                                System.out.println(eachStudent);
                            }
                            break;

                        case 7 :
                            // Update Student address
                            System.out.println("Enter detail to Update Student Address: ");
                            System.out.println("Enter Existing Student's id : ");
                            int existingStudentId = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Street :");
                            String streetsToUpdate = sc.nextLine();
                            System.out.println("Enter city : ");
                            String citysToUpdate = sc.nextLine();
                            System.out.println("Enter State :");
                            String statesToUpdate = sc.nextLine();
                            System.out.println("Enter Country : ");
                            String countrysToUpdate = sc.nextLine();
                            System.out.println("Enter Pincode : ");
                            String pinCodesToUpdate = sc.nextLine();
                            System.out.println(student.updateAddress(new Student(existingStudentId,new Address(streetsToUpdate,citysToUpdate,statesToUpdate,countrysToUpdate,pinCodesToUpdate))));
                            break;
                        case 8 :
                            // Add Phone Numbers
                            System.out.println("Enter Existing Student's id : ");
                            int existingStudentIds = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Phone Number : ");
                            String newPhoneNumber = sc.nextLine();
                            Set<String> newPhoneNumbers = new HashSet<>();
                            newPhoneNumbers.add(newPhoneNumber);
                            System.out.println(student.addNewNumber(new Student(existingStudentIds, newPhoneNumbers)));
                            break;
                        default:
                            // Exit from student section
                            start = 0;
                            System.out.println("Exited from student !");
                    }
                }
            }else if(option == 2){
                // course
                System.out.println("Course Section --->");
                while(start == 1){
                    System.out.println("Select Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Course\n2. Update Existing Course\n3. Delete Existing Course\n4. Get Course By Id\n5. Get Course by Name\n6. Get All Available Courses");
                    System.out.println("Enter Option Here : ");
                    int courseOperation = sc.nextInt();

                    switch(courseOperation){
                        case 1 :
                            // Register for new course
                            System.out.println("Enter course details :");
                            sc.nextLine();
                            System.out.println("Enter course name : ");
                            String name = sc.nextLine();
                            System.out.println("Enter Duration : ");
                            String duration = sc.nextLine();
                            System.out.println("Course Fees : ");
                            long fees = sc.nextLong();
                            sc.nextLine();
                            System.out.println("Enter Trainer name : ");
                            String trainerName = sc.nextLine();
                            Set<String> trainer = new HashSet<>();
                            trainer.add(trainerName);
                            System.out.println(course.registerNewCourse(new Course(name, duration, fees, trainer)));
                            break;

                        case 2 :
                            // update course
                            System.out.println("Enter detail to Update Course :");
                            System.out.println("Enter Existing Course id : ");
                            int existingCourseId = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Course Name : ");
                            String updatedCourseName = sc.nextLine();
                            System.out.println("Enter Duration : ");
                            String updatedCourseDuration = sc.nextLine();
                            System.out.println("Enter Course Fees : ");
                            long updatedCourseFees = sc.nextLong();
                            sc.nextLine();
                            System.out.println("Enter Trainer name : ");
                            String trainersName = sc.nextLine();
                            Set<String> trainers = new HashSet<>();
                            trainers.add(trainersName);
                            System.out.println(course.updateCourse(new Course(existingCourseId, updatedCourseName, updatedCourseDuration, updatedCourseFees, trainers)));
                            break;

                        case 3 :
                            // delete course
                            System.out.println("Enter Course Id : ");
                            int courseIdToDelete = sc.nextInt();
                            course.removeCourse(courseIdToDelete);
                            break;

                        case 4 :
                            // Get course by id
                            System.out.println("Enter course id : ");
                            int courseId = sc.nextInt();
                            System.out.println(course.getById(courseId));
                            break;

                        case 5 :
                            // Get Course by Name
                            System.out.println("Enter Course Name : ");
                            String courseName = sc.next();
                            System.out.println(course.getByName(courseName));
                            break;

                        case 6 :
                            // find all courses
                            List<Course> allCourses = course.getAllCourses();
                            for(Course eachCourse : allCourses){
                                System.out.println(eachCourse);
                            }
                            break;

                        default:
                            // default to exit from course section
                            start = 0;
                            System.out.println("Exited from Course !");

                    }
                }

            }else{
                System.out.println("Invalid Input Entered !");
            }

            System.out.println("Home --->");
            System.out.println("1. to continue \n2. to Stope");
            System.out.println("Enter Here : ");
            start = sc.nextInt();
        }
        System.out.println("--- Application Stopped ---");

         */


























//StudentRepositoryImpl obj = new StudentRepositoryImpl();
//
//        System.out.println(obj.findAll());
//        System.out.println(obj.save(new Student("Dipak Santosh Bhide","dipak.sb@gmail.com","comp")));
// System.out.println(obj.findById(1120));
//  System.out.println(obj.update(new Student(1120,"Dipak Santosh Bhide","dipak.sb@gmail.com","comp")));
//obj.remove(new Student(1121,"Dipak Santosh Bhide","dipak.sb@gmail.com","comp"));
//    System.out.println(obj.findByEmail("swaaj@gmail.com"));
//
//        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("StudentCourseManagement");
//        EntityManager entityManager = entityManagerFactory.createEntityManager();
//        entityManager.getTransaction().begin();
//        Student student = new Student("vishal","v@gmail.com","arts");
//        entityManager.persist(student);
//        Student student2 = new Student("swaraj","swaraj@gmail.com","science");
//        entityManager.persist(student2);
//        entityManager.getTransaction().commit();
//        entityManager.close();

//        entityManager.getTransaction().begin();
//        Course course = new Course("Physics","4 months",20000L);
//        entityManager.persist(course);
//        entityManager.getTransaction().commit();
//        entityManager.close();

