package com.scm.service;

import com.scm.entity.Course;

import java.util.List;

public interface CourseService {

    Course getById(Integer courseId);

    List<Course> getAllCourses();

    Course getByName(String courseName);

    Course registerNewCourse(Course newCourse);

    Course updateCourse(Course updatedCourse);

    void removeCourse(Integer courseId);
}
