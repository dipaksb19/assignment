package com.scm.repositoryimpl;

import com.scm.entity.Course;
import com.scm.entitymanager.EntityManagerUtilityClass;
import com.scm.repository.CourseRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

import java.util.List;
import java.util.Optional;

public class CourseRepositoryImpl implements CourseRepository {

    private final EntityManagerFactory entityManagerFactory = EntityManagerUtilityClass.getEntityManagerFactoryInstance();
    private EntityManager entityManager = entityManagerFactory.createEntityManager();
    private EntityTransaction transaction = entityManager.getTransaction();

    void closeEntityManager(){
        entityManager.close();
    }

    @Override
    public Optional<Course> findById(Integer courseId) {
        Optional<Course> course = Optional.ofNullable(entityManager.find(Course.class, courseId));
        return course;
    }

    @Override
    public List<Course> findAll() {
        TypedQuery<Course> courseList = entityManager.createQuery("select e from Course e", Course.class);
        return courseList.getResultList();
    }

    @Override
    public Optional<Course> findByName(String courseName) {
        TypedQuery<Course> courseByName = entityManager.createQuery("select e from Course e where e.courseName =: courseName", Course.class);
        courseByName.setParameter("courseName", courseName);
        List<Course> resultList = courseByName.getResultList();
        Optional<Course> databaseCourse = resultList.stream().findFirst();
        return databaseCourse;
    }

    @Override
    public Course save(Course newCourse) {
        transaction.begin();
        entityManager.persist(newCourse);
        transaction.commit();
        return newCourse;
    }

    @Override
    public Course update(Course updatedCourse) {
        transaction.begin();
        Course dbCourse = entityManager.merge(updatedCourse);
        transaction.commit();
        return dbCourse;
    }

    @Override
    public void remove(Course course) {
        transaction.begin();
        entityManager.remove(course);
        transaction.commit();
    }
}
