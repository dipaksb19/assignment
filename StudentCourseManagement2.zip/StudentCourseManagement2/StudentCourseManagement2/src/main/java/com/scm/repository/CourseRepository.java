package com.scm.repository;

import com.scm.entity.Course;

import java.util.List;
import java.util.Optional;

public interface CourseRepository {

    Optional<Course> findById(Integer courseId);

    List<Course> findAll();

    Optional<Course> findByName(String courseName);

    Course save(Course newCourse);

    Course update(Course updatedCourse);

    void remove(Course course);
}
