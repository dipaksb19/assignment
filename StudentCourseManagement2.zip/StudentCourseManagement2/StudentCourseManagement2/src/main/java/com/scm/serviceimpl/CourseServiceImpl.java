package com.scm.serviceimpl;

import com.scm.entity.Course;
import com.scm.exception.CourseAlreadyExistException;
import com.scm.exception.CourseDoesNotExistException;
import com.scm.repository.CourseRepository;
import com.scm.repositoryimpl.CourseRepositoryImpl;
import com.scm.service.CourseService;
import com.scm.serviceimpl.validate.CourseValidator;

import java.util.List;
import java.util.Optional;

public class CourseServiceImpl implements CourseService {

    private CourseRepository courseRepository = new CourseRepositoryImpl();

    @Override
    public Course getById(Integer courseId) {
        Optional<Course> existingCourse = courseRepository.findById(courseId);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with id - " + courseId);
        }
        return existingCourse.get();
    }

    @Override
    public List<Course> getAllCourses() {
        List<Course> allCourses = courseRepository.findAll();
        return allCourses
                .stream()
                .sorted((x,y) -> Math.toIntExact(x.getCoursePrice() - y.getCoursePrice()))
                .toList();
    }

    @Override
    public Course getByName(String courseName) {
        Optional<Course> existingCourse = courseRepository.findByName(courseName);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with name - " + courseName);
        }
        return existingCourse.get();
    }

    @Override
    public Course registerNewCourse(Course newCourse) {
        CourseValidator.validate(newCourse);
        Optional<Course> existingCourse = courseRepository.findByName(newCourse.getCourseName());
        if(existingCourse.isPresent()){
            throw new CourseAlreadyExistException("Course already exist with name - " + newCourse.getCourseName());
        }
        return courseRepository.save(newCourse);
    }

    @Override
    public Course updateCourse(Course updatedCourse) {
        Optional<Course> existingCourse = courseRepository.findById(updatedCourse.getId());
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with id - " + updatedCourse.getId());
        }
        existingCourse.get().setCourseName(updatedCourse.getCourseName());
        existingCourse.get().setCourseDuration(updatedCourse.getCourseDuration());
        existingCourse.get().setCoursePrice(updatedCourse.getCoursePrice());
        return courseRepository.update(existingCourse.get());
    }

    @Override
    public void removeCourse(Integer courseId) {
        Optional<Course> existingCourse = courseRepository.findById(courseId);
        if(existingCourse.isEmpty()){
            throw new CourseDoesNotExistException("Course does not exist with id - " + courseId);
        }
        courseRepository.remove(existingCourse.get());
    }
}
