package com.scm.entity;


public class Trainer {
}
